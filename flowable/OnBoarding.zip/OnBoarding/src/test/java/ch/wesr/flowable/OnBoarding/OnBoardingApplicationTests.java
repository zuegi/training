package ch.wesr.flowable.OnBoarding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnBoardingApplicationTests {

	@Test
	void contextLoads() {
	}

}
